/*
 * timer0.h
 *
 * Created: 26/04/2022 04:42:45 p. m.
 *  Author: jdgar
 */ 


#ifndef TIMER0_H_
#define TIMER0_H_

void timer0_init(void);
void timer0_on(void);
void timer0_off(void);

#endif /* TIMER0_H_ */