/****************************************************
 * LLENAR ESTE ESPACIO CON LOS SIGUIENTES DATOS:    *
 * Nombre:                                          *
 * Hora clase:                                      *
 * D�a:                                             *
 * N� de lista:                                     *
 * N� de Equipo:                                    *
 * Dispositivo:                                     *
 * Rev:                                             *
 * Prop�sito de la actividad:                       *
 *                                                  *
 *                                    Fecha:        *
 ***************************************************/

#include <avr/io.h>
#define F_CPU 1000000UL // 1Mhz
#include <util/delay.h> // Biblioteca de retardos
#include <avr/interrupt.h>
#include "debouncing/debouncing.h"
#include "int_ext/ext_int.h"
#include "timer0/timer0.h"


//--Salidas

//--Display
#define DISPLAY PORTD
//--Barrido
#define B1 PORTB0 
#define B2 PORTB1 
#define B3 PORTB2 
#define B4 PORTB3

#define N0 0xFC
#define N1 0x60
#define N2 0xDA
#define N3 0xF2
#define N4 0x66
#define N5 0xB6
#define N6 0xBE
#define N7 0xE0
#define N8 0xFE
#define N9 0xE6

 

//--Declaracion de funciones
void init_ports(void);
void showNumber(int number);


//--Variable global
uint8_t k;
//uint8_t i = 0;
volatile int z = 0;
volatile int val = 0;
volatile int i = 0;
int millares = 0;
int centenas = 0;
int decenas = 0;
int unidades = 0;
//-Array
                    //0    1    2    3    4    5    6
uint8_t numeros[10] ={0xFC,0x60,0xDA,0xF2,0x66,0xB6,0xBE,0xE0,0xFE,0xE6};
uint8_t selector[4];	
////////////-----MAIN-----//////////////////
int main(void)
{
	cli();
	init_ports();
	timer0_init();
	sei();
	timer0_on();
	while (1)
	{     //1234	
		z = 1234;
		millares =  z / 1000; // Display millares 1
		centenas = (z % 1000)/100; // Display centenas 2
		decenas = (z % 100)/10; // Display decenas 3
		unidades =  z % 10; // Display unidades 4
		PORTB = ~(1<<i);
		if (i == 0)
		{
			showNumber(millares);
		}
		else if (i == 1)
		{
			showNumber(centenas);
		}
		else if (i == 2)
		{
			showNumber(decenas);
		}
		else if (i == 3)
		{
			showNumber(unidades);
		}


		//DISPLAY = numeros[selector[i]];

	} // Fin while
} // Fin main

void init_ports(void)
{
//--Outputs
	//--DISPLAY
	DDRD = 0xFF;
	DDRB |= _BV(B1) | _BV(B2) | _BV(B3) | _BV(B4);
	
}
void showNumber(int number)
{
	switch (number)
	{
		case 0:
		DISPLAY = N0;
		break;
		case 1:
		DISPLAY = N1;
		break;
		case 2:
		DISPLAY = N2;
		break;
		case 3:
		DISPLAY = N3;
		break;
		case 4:
		DISPLAY = N4;
		break;
	}
}
ISR (TIMER0_COMPA_vect)
{
	if (i == 0)
	{
		showNumber(millares);
	}
	else if (i == 1)
	{
		showNumber(centenas);
	}
	else if (i == 2)
	{
		showNumber(decenas);
	}
	else if (i == 3)
	{
		showNumber(unidades);
	}
	if (i >= 3)
	{
		i = 0;
	}
	else
	{
		i++;
	}
}



