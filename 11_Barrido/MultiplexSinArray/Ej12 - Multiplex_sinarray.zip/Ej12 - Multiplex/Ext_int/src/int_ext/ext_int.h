/*
 * ext_int.h
 *
 * Created: 26/04/2022 04:19:16 p. m.
 *  Author: jdgar
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_


void init_ext_int(void);


#endif /* EXT_INT_H_ */