/*
 * ADS.h
 *
 * Created: 10/05/2022 04:07:59 p. m.
 *  Author: jdgar
 */ 


#ifndef ADS_H_
#define ADS_H_

#include <avr/io.h>
void ADC_init(void);
void ADC_on(void);



#endif /* ADS_H_ */